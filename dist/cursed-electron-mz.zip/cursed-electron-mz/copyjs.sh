#!/bin/bash

mkdir project/js/plugins
cp src/plugins/*.js project/js/plugins
