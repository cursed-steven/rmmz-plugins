import glob from "glob";

/** @var {Partial<import('esbuild').BuildOptions>} */
export const platform = "node";
export const entryPoints = glob.sync("src/main/*.ts");
export const bundle = true;
export const target = "node14.16.0";
export const loader = {
    ".ts": "ts",
};
