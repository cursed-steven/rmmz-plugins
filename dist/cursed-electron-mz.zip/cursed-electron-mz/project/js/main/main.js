var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main/main.ts
var main_exports = {};
__export(main_exports, {
  mainWindowHeight: () => mainWindowHeight,
  mainWindowWidth: () => mainWindowWidth
});
module.exports = __toCommonJS(main_exports);
var import_node_path = __toESM(require("path"));
var import_node_fs = __toESM(require("fs"));
var import_buffer = require("buffer");
var import_electron = require("electron");
function isDev() {
  return true;
}
function isDarwin() {
  return process.platform === "darwin";
}
var mainWindow;
var mainWindowWidth = 816;
var mainWindowHeight = isDarwin() ? 652 : 624;
function onAppResize() {
  const size = mainWindow.getSize();
  const width = size[0];
  const zoom = width / mainWindowWidth;
  mainWindow.webContents.setZoomFactor(zoom);
}
function createWindow() {
  const iconPath = isDev() ? "icon/icon.png" : "project/icon/icon.png";
  const indexPath = isDev() ? "../../index.html" : "project/index.html";
  mainWindow = new import_electron.BrowserWindow({
    width: mainWindowWidth,
    height: mainWindowHeight,
    minWidth: mainWindowWidth,
    minHeight: isDarwin() ? mainWindowHeight + 28 : mainWindowHeight,
    icon: iconPath,
    webPreferences: {
      preload: import_node_path.default.resolve(__dirname, "preload.js")
    }
  });
  mainWindow.on("resize", () => {
    onAppResize();
  });
  mainWindow.setMenu(null);
  mainWindow.setAspectRatio(17 / 13);
  mainWindow.loadFile(indexPath).then(onAppResize);
  if (isDev()) {
    mainWindow.webContents.openDevTools({ mode: "detach" });
  }
}
import_electron.app.whenReady().then(createWindow);
import_electron.app.on("activate", () => {
  if (mainWindow === null) {
    createWindow();
  }
});
import_electron.app.once("window-all-closed", () => import_electron.app.quit());
import_electron.ipcMain.handle("isDev", (e) => {
  return isDev();
});
import_electron.ipcMain.handle("saveDir", (e) => {
  return import_node_path.default.join(import_node_path.default.resolve(require.main.filename, "../../.."), "save/");
});
import_electron.ipcMain.handle("dataDir", (e) => {
  return import_node_path.default.join(import_node_path.default.resolve(require.main.filename, "../../.."), "data/");
});
import_electron.ipcMain.handle("exists", (e, filePath) => {
  return import_node_fs.default.existsSync(filePath);
});
import_electron.ipcMain.on("mkdir", (e, dirPath) => {
  if (!import_node_fs.default.existsSync(dirPath)) {
    import_node_fs.default.mkdirSync(dirPath);
  }
});
import_electron.ipcMain.on("rm", (e, filePath) => {
  if (import_node_fs.default.existsSync(filePath)) {
    import_node_fs.default.unlinkSync(filePath);
  }
});
import_electron.ipcMain.on("mv", (e, oldPath, newPath) => {
  if (import_node_fs.default.existsSync(oldPath)) {
    import_node_fs.default.renameSync(oldPath, newPath);
  }
});
import_electron.ipcMain.handle("readFile", (e, filePath) => {
  if (import_node_fs.default.existsSync(filePath)) {
    return import_node_fs.default.readFileSync(filePath, { encoding: "utf8" });
  } else {
    return null;
  }
});
import_electron.ipcMain.on("writeFile", (e, filePath, data) => {
  import_node_fs.default.writeFileSync(
    filePath,
    typeof data === "string" ? data : import_buffer.Buffer.from(data)
  );
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  mainWindowHeight,
  mainWindowWidth
});
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vLi4vc3JjL21haW4vbWFpbi50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyo9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuIG1haW4udHNcbi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiBWZXJzaW9uIEhpc3Rvcnk6XG4gMS4wLjAgMjAyMy8wNi8xMyBjdXJzZWRfc3RldmVuICAgICBcdTUyMURcdTcyNDhcbiAxLjAuMSAyMDI0LzA0LzE2IGN1cnNlZF9zdGV2ZW4gICAgIFx1MzBCOVx1MzBCMVx1MzBGQ1x1MzBFQVx1MzBGM1x1MzBCMFx1NUJGRVx1NUZEQ1xuIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuIENvbnRhY3Q6XG4gW1R3aXR0ZXJdICBodHRwczovL3R3aXR0ZXIuY29tL2N1cnNlZF9zdGV2ZW5cbiBbbm90ZV0gICAgIGh0dHBzOi8vbm90ZS5jb20vY3Vyc2VkX3N0ZXZlbi9uL241NmM0Y2Q1MjU1OGVcbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cblxuaW1wb3J0IHBhdGggZnJvbSBcIm5vZGU6cGF0aFwiO1xuaW1wb3J0IGZzIGZyb20gXCJub2RlOmZzXCI7XG5pbXBvcnQgeyBCdWZmZXIgfSBmcm9tIFwiYnVmZmVyXCI7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm9kZS9uby11bnB1Ymxpc2hlZC1pbXBvcnRcbmltcG9ydCB7IEJyb3dzZXJXaW5kb3csIGFwcCwgaXBjTWFpbiB9IGZyb20gXCJlbGVjdHJvblwiO1xuXG5mdW5jdGlvbiBpc0RldigpIHtcbiAgICAvLyBjb25zb2xlLmxvZyhcImVudjogXCIsIHByb2Nlc3MuZW52Lk5PREVfRU5WKTtcbiAgICByZXR1cm4gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwiZGV2ZWxvcG1lbnRcIjtcbn1cblxuZnVuY3Rpb24gaXNEYXJ3aW4oKSB7XG4gICAgcmV0dXJuIHByb2Nlc3MucGxhdGZvcm0gPT09IFwiZGFyd2luXCI7XG59XG5cbmxldCBtYWluV2luZG93OiBCcm93c2VyV2luZG93O1xuZXhwb3J0IGNvbnN0IG1haW5XaW5kb3dXaWR0aCA9IDgxNjtcbi8vIG1hY09TXHUzMDZFXHU1ODM0XHU1NDA4XHUzMDZFXHUzMDdGXHU2NzJDXHU2NzY1XHUzMDZFXHUzMEI1XHUzMEE0XHUzMEJBKzI4XG5leHBvcnQgY29uc3QgbWFpbldpbmRvd0hlaWdodCA9IGlzRGFyd2luKCkgPyA2NTIgOiA2MjQ7XG5cbmZ1bmN0aW9uIG9uQXBwUmVzaXplKCkge1xuICAgIGNvbnN0IHNpemUgPSBtYWluV2luZG93LmdldFNpemUoKTtcbiAgICBjb25zdCB3aWR0aCA9IHNpemVbMF07XG4gICAgY29uc3Qgem9vbSA9IHdpZHRoIC8gbWFpbldpbmRvd1dpZHRoO1xuICAgIG1haW5XaW5kb3cud2ViQ29udGVudHMuc2V0Wm9vbUZhY3Rvcih6b29tKTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlV2luZG93KCkge1xuICAgIGNvbnN0IGljb25QYXRoID0gaXNEZXYoKSA/IFwiaWNvbi9pY29uLnBuZ1wiIDogXCJwcm9qZWN0L2ljb24vaWNvbi5wbmdcIjtcbiAgICBjb25zdCBpbmRleFBhdGggPSBpc0RldigpID8gXCIuLi8uLi9pbmRleC5odG1sXCIgOiBcInByb2plY3QvaW5kZXguaHRtbFwiO1xuXG4gICAgbWFpbldpbmRvdyA9IG5ldyBCcm93c2VyV2luZG93KHtcbiAgICAgICAgd2lkdGg6IG1haW5XaW5kb3dXaWR0aCxcbiAgICAgICAgaGVpZ2h0OiBtYWluV2luZG93SGVpZ2h0LFxuICAgICAgICBtaW5XaWR0aDogbWFpbldpbmRvd1dpZHRoLFxuICAgICAgICBtaW5IZWlnaHQ6IGlzRGFyd2luKCkgPyBtYWluV2luZG93SGVpZ2h0ICsgMjggOiBtYWluV2luZG93SGVpZ2h0LFxuICAgICAgICBpY29uOiBpY29uUGF0aCxcbiAgICAgICAgd2ViUHJlZmVyZW5jZXM6IHtcbiAgICAgICAgICAgIHByZWxvYWQ6IHBhdGgucmVzb2x2ZShfX2Rpcm5hbWUsIFwicHJlbG9hZC5qc1wiKSxcbiAgICAgICAgfSxcbiAgICB9KTtcbiAgICBtYWluV2luZG93Lm9uKFwicmVzaXplXCIsICgpID0+IHtcbiAgICAgICAgb25BcHBSZXNpemUoKTtcbiAgICB9KTtcbiAgICBtYWluV2luZG93LnNldE1lbnUobnVsbCk7XG4gICAgbWFpbldpbmRvdy5zZXRBc3BlY3RSYXRpbygxNyAvIDEzKTtcblxuICAgIG1haW5XaW5kb3cubG9hZEZpbGUoaW5kZXhQYXRoKS50aGVuKG9uQXBwUmVzaXplKTtcbiAgICBpZiAoaXNEZXYoKSkge1xuICAgICAgICBtYWluV2luZG93LndlYkNvbnRlbnRzLm9wZW5EZXZUb29scyh7IG1vZGU6IFwiZGV0YWNoXCIgfSk7XG4gICAgfVxufVxuYXBwLndoZW5SZWFkeSgpLnRoZW4oY3JlYXRlV2luZG93KTtcblxuLy8gbWFjT1NcdTMwNjdcdTMwQzlcdTMwQzNcdTMwQUZcdTMwQTJcdTMwQTRcdTMwQjNcdTMwRjNcdTMwOTJcdTMwQUZcdTMwRUFcdTMwQzNcdTMwQUZcdTMwNTdcdTMwNUZcdTMwNjhcdTMwNERcdTMwNkJcdTMwQTZcdTMwQTNcdTMwRjNcdTMwQzlcdTMwQTZcdTMwOTJcdTUxOERcdTRGNUNcdTYyMTBcdTMwNTlcdTMwOEJcbmFwcC5vbihcImFjdGl2YXRlXCIsICgpID0+IHtcbiAgICBpZiAobWFpbldpbmRvdyA9PT0gbnVsbCkge1xuICAgICAgICBjcmVhdGVXaW5kb3coKTtcbiAgICB9XG59KTtcbmFwcC5vbmNlKFwid2luZG93LWFsbC1jbG9zZWRcIiwgKCkgPT4gYXBwLnF1aXQoKSk7XG5cbmlwY01haW4uaGFuZGxlKFwiaXNEZXZcIiwgKGUpID0+IHtcbiAgICAvLyByZXR1cm4gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwiZGV2ZWxvcG1lbnRcIjtcbiAgICByZXR1cm4gaXNEZXYoKTtcbn0pO1xuXG5pcGNNYWluLmhhbmRsZShcInNhdmVEaXJcIiwgKGUpID0+IHtcbiAgICByZXR1cm4gcGF0aC5qb2luKHBhdGgucmVzb2x2ZShyZXF1aXJlLm1haW4uZmlsZW5hbWUsIFwiLi4vLi4vLi5cIiksIFwic2F2ZS9cIik7XG59KTtcblxuaXBjTWFpbi5oYW5kbGUoXCJkYXRhRGlyXCIsIChlKSA9PiB7XG4gICAgcmV0dXJuIHBhdGguam9pbihwYXRoLnJlc29sdmUocmVxdWlyZS5tYWluLmZpbGVuYW1lLCBcIi4uLy4uLy4uXCIpLCBcImRhdGEvXCIpO1xufSk7XG5cbmlwY01haW4uaGFuZGxlKFwiZXhpc3RzXCIsIChlLCBmaWxlUGF0aCkgPT4ge1xuICAgIHJldHVybiBmcy5leGlzdHNTeW5jKGZpbGVQYXRoKTtcbn0pO1xuXG5pcGNNYWluLm9uKFwibWtkaXJcIiwgKGUsIGRpclBhdGgpID0+IHtcbiAgICBpZiAoIWZzLmV4aXN0c1N5bmMoZGlyUGF0aCkpIHtcbiAgICAgICAgZnMubWtkaXJTeW5jKGRpclBhdGgpO1xuICAgIH1cbn0pO1xuXG5pcGNNYWluLm9uKFwicm1cIiwgKGUsIGZpbGVQYXRoKSA9PiB7XG4gICAgaWYgKGZzLmV4aXN0c1N5bmMoZmlsZVBhdGgpKSB7XG4gICAgICAgIGZzLnVubGlua1N5bmMoZmlsZVBhdGgpO1xuICAgIH1cbn0pO1xuXG5pcGNNYWluLm9uKFwibXZcIiwgKGUsIG9sZFBhdGgsIG5ld1BhdGgpID0+IHtcbiAgICBpZiAoZnMuZXhpc3RzU3luYyhvbGRQYXRoKSkge1xuICAgICAgICBmcy5yZW5hbWVTeW5jKG9sZFBhdGgsIG5ld1BhdGgpO1xuICAgIH1cbn0pO1xuXG5pcGNNYWluLmhhbmRsZShcInJlYWRGaWxlXCIsIChlLCBmaWxlUGF0aCkgPT4ge1xuICAgIGlmIChmcy5leGlzdHNTeW5jKGZpbGVQYXRoKSkge1xuICAgICAgICByZXR1cm4gZnMucmVhZEZpbGVTeW5jKGZpbGVQYXRoLCB7IGVuY29kaW5nOiBcInV0ZjhcIiB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59KTtcblxuaXBjTWFpbi5vbihcIndyaXRlRmlsZVwiLCAoZSwgZmlsZVBhdGgsIGRhdGEpID0+IHtcbiAgICBmcy53cml0ZUZpbGVTeW5jKFxuICAgICAgICBmaWxlUGF0aCxcbiAgICAgICAgdHlwZW9mIGRhdGEgPT09IFwic3RyaW5nXCIgPyBkYXRhIDogQnVmZmVyLmZyb20oZGF0YSlcbiAgICApO1xufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVlBLHVCQUFpQjtBQUNqQixxQkFBZTtBQUNmLG9CQUF1QjtBQUV2QixzQkFBNEM7QUFFNUMsU0FBUyxRQUFRO0FBRWIsU0FBTztBQUNYO0FBRUEsU0FBUyxXQUFXO0FBQ2hCLFNBQU8sUUFBUSxhQUFhO0FBQ2hDO0FBRUEsSUFBSTtBQUNHLElBQU0sa0JBQWtCO0FBRXhCLElBQU0sbUJBQW1CLFNBQVMsSUFBSSxNQUFNO0FBRW5ELFNBQVMsY0FBYztBQUNuQixRQUFNLE9BQU8sV0FBVyxRQUFRO0FBQ2hDLFFBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsUUFBTSxPQUFPLFFBQVE7QUFDckIsYUFBVyxZQUFZLGNBQWMsSUFBSTtBQUM3QztBQUVBLFNBQVMsZUFBZTtBQUNwQixRQUFNLFdBQVcsTUFBTSxJQUFJLGtCQUFrQjtBQUM3QyxRQUFNLFlBQVksTUFBTSxJQUFJLHFCQUFxQjtBQUVqRCxlQUFhLElBQUksOEJBQWM7QUFBQSxJQUMzQixPQUFPO0FBQUEsSUFDUCxRQUFRO0FBQUEsSUFDUixVQUFVO0FBQUEsSUFDVixXQUFXLFNBQVMsSUFBSSxtQkFBbUIsS0FBSztBQUFBLElBQ2hELE1BQU07QUFBQSxJQUNOLGdCQUFnQjtBQUFBLE1BQ1osU0FBUyxpQkFBQUEsUUFBSyxRQUFRLFdBQVcsWUFBWTtBQUFBLElBQ2pEO0FBQUEsRUFDSixDQUFDO0FBQ0QsYUFBVyxHQUFHLFVBQVUsTUFBTTtBQUMxQixnQkFBWTtBQUFBLEVBQ2hCLENBQUM7QUFDRCxhQUFXLFFBQVEsSUFBSTtBQUN2QixhQUFXLGVBQWUsS0FBSyxFQUFFO0FBRWpDLGFBQVcsU0FBUyxTQUFTLEVBQUUsS0FBSyxXQUFXO0FBQy9DLE1BQUksTUFBTSxHQUFHO0FBQ1QsZUFBVyxZQUFZLGFBQWEsRUFBRSxNQUFNLFNBQVMsQ0FBQztBQUFBLEVBQzFEO0FBQ0o7QUFDQSxvQkFBSSxVQUFVLEVBQUUsS0FBSyxZQUFZO0FBR2pDLG9CQUFJLEdBQUcsWUFBWSxNQUFNO0FBQ3JCLE1BQUksZUFBZSxNQUFNO0FBQ3JCLGlCQUFhO0FBQUEsRUFDakI7QUFDSixDQUFDO0FBQ0Qsb0JBQUksS0FBSyxxQkFBcUIsTUFBTSxvQkFBSSxLQUFLLENBQUM7QUFFOUMsd0JBQVEsT0FBTyxTQUFTLENBQUMsTUFBTTtBQUUzQixTQUFPLE1BQU07QUFDakIsQ0FBQztBQUVELHdCQUFRLE9BQU8sV0FBVyxDQUFDLE1BQU07QUFDN0IsU0FBTyxpQkFBQUEsUUFBSyxLQUFLLGlCQUFBQSxRQUFLLFFBQVEsUUFBUSxLQUFLLFVBQVUsVUFBVSxHQUFHLE9BQU87QUFDN0UsQ0FBQztBQUVELHdCQUFRLE9BQU8sV0FBVyxDQUFDLE1BQU07QUFDN0IsU0FBTyxpQkFBQUEsUUFBSyxLQUFLLGlCQUFBQSxRQUFLLFFBQVEsUUFBUSxLQUFLLFVBQVUsVUFBVSxHQUFHLE9BQU87QUFDN0UsQ0FBQztBQUVELHdCQUFRLE9BQU8sVUFBVSxDQUFDLEdBQUcsYUFBYTtBQUN0QyxTQUFPLGVBQUFDLFFBQUcsV0FBVyxRQUFRO0FBQ2pDLENBQUM7QUFFRCx3QkFBUSxHQUFHLFNBQVMsQ0FBQyxHQUFHLFlBQVk7QUFDaEMsTUFBSSxDQUFDLGVBQUFBLFFBQUcsV0FBVyxPQUFPLEdBQUc7QUFDekIsbUJBQUFBLFFBQUcsVUFBVSxPQUFPO0FBQUEsRUFDeEI7QUFDSixDQUFDO0FBRUQsd0JBQVEsR0FBRyxNQUFNLENBQUMsR0FBRyxhQUFhO0FBQzlCLE1BQUksZUFBQUEsUUFBRyxXQUFXLFFBQVEsR0FBRztBQUN6QixtQkFBQUEsUUFBRyxXQUFXLFFBQVE7QUFBQSxFQUMxQjtBQUNKLENBQUM7QUFFRCx3QkFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLFNBQVMsWUFBWTtBQUN0QyxNQUFJLGVBQUFBLFFBQUcsV0FBVyxPQUFPLEdBQUc7QUFDeEIsbUJBQUFBLFFBQUcsV0FBVyxTQUFTLE9BQU87QUFBQSxFQUNsQztBQUNKLENBQUM7QUFFRCx3QkFBUSxPQUFPLFlBQVksQ0FBQyxHQUFHLGFBQWE7QUFDeEMsTUFBSSxlQUFBQSxRQUFHLFdBQVcsUUFBUSxHQUFHO0FBQ3pCLFdBQU8sZUFBQUEsUUFBRyxhQUFhLFVBQVUsRUFBRSxVQUFVLE9BQU8sQ0FBQztBQUFBLEVBQ3pELE9BQU87QUFDSCxXQUFPO0FBQUEsRUFDWDtBQUNKLENBQUM7QUFFRCx3QkFBUSxHQUFHLGFBQWEsQ0FBQyxHQUFHLFVBQVUsU0FBUztBQUMzQyxpQkFBQUEsUUFBRztBQUFBLElBQ0M7QUFBQSxJQUNBLE9BQU8sU0FBUyxXQUFXLE9BQU8scUJBQU8sS0FBSyxJQUFJO0FBQUEsRUFDdEQ7QUFDSixDQUFDOyIsCiAgIm5hbWVzIjogWyJwYXRoIiwgImZzIl0KfQo=
