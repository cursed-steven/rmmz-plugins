(() => {
  // src/plugins/CSVN_battleBgm.ts
  var CSVN_battleBgm = {
    params: PluginManagerEx.createParameter(document.currentScript),
    ipcRenderer: null
  };
  var battleBgmList = CSVN_battleBgm.params.list;
  var _BattleManager_playBattleBgm_bbg = BattleManager.playBattleBgm;
  BattleManager.playBattleBgm = function() {
    const troopId = $gameTroop._troopId;
    const battleBgm = battleBgmList.find(
      (b) => b.troopId === troopId
    );
    if (battleBgm) {
      if (battleBgm.bgm) {
        AudioManager.playBgm(battleBgm.bgm, 0);
      } else {
        AudioManager.replayBgm(BattleManager._mapBgm);
      }
      if (battleBgm.bgs) {
        AudioManager.playBgs(battleBgm.bgs, 0);
      } else {
        AudioManager.replayBgs(BattleManager._mapBgs);
      }
    } else {
      _BattleManager_playBattleBgm_bbg.call(this);
    }
  };
})();
/*:ja
 * @target MZ
 * @plugindesc 敵グループごとに戦闘BGMを設定する
 * @author cursed_steven
 * @base PluginCommonBase
 * @orderAfter PluginCommonBase
 * @preserve
 *
 * @help
 * RPG Maker MZ - CSVN_battleBgm.ts (transpiled)
 * ----------------------------------------------------------------------------
 * (C)2023 cursed_steven
 * This software is released under the MIT License.
 * http://opensource.org/licenses/mit-license.php
 * ----------------------------------------------------------------------------
 * Version
 * 1.0.0  2023/07/02 初版
 * 1.1.0  2024/05/06 公開用に一部修正
 * ----------------------------------------------------------------------------
 * [Twitter]: https://twitter.com/cursed_steven
 *
 * 戦闘BGMを敵グループごとに、プラグインパラメータで個別に設定できます。
 *
 * @param list
 * @text 設定リスト
 * @type struct<BattleBgm>[]
 */
/*~struct~BattleBgm:ja
 *
 * @preserve
 *
 * @param troopId
 * @text 敵グループ
 * @type troop
 *
 * @param bgm
 * @text BGM
 * @type struct<BgmSetting>
 *
 * @param bgs
 * @text BGS
 * @type struct<BgsSetting>
 */
/*~struct~BgmSetting:ja
 *
 * @preserve
 *
 * @param name
 * @text ファイル名
 * @type file
 * @dir audio/bgm/
 *
 * @param volume
 * @text 音量
 * @type number
 * @default 90
 *
 * @param pitch
 * @text ピッチ
 * @type number
 * @default 100
 *
 * @param pan
 * @text パン
 * @type number
 * @default 0
 */
/*~struct~BgsSetting:ja
 *
 * @preserve
 *
 * @param name
 * @text ファイル名
 * @type file
 * @dir audio/bgs/
 *
 * @param volume
 * @text 音量
 * @type number
 * @default 90
 *
 * @param pitch
 * @text ピッチ
 * @type number
 * @default 100
 *
 * @param pan
 * @text パン
 * @type number
 * @default 0
 */
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vLi4vc3JjL3BsdWdpbnMvQ1NWTl9iYXR0bGVCZ20udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qOmphXG4gKiBAdGFyZ2V0IE1aXG4gKiBAcGx1Z2luZGVzYyBcdTY1NzVcdTMwQjBcdTMwRUJcdTMwRkNcdTMwRDdcdTMwNTRcdTMwNjhcdTMwNkJcdTYyMjZcdTk1RDhCR01cdTMwOTJcdThBMkRcdTVCOUFcdTMwNTlcdTMwOEJcbiAqIEBhdXRob3IgY3Vyc2VkX3N0ZXZlblxuICogQGJhc2UgUGx1Z2luQ29tbW9uQmFzZVxuICogQG9yZGVyQWZ0ZXIgUGx1Z2luQ29tbW9uQmFzZVxuICogQHByZXNlcnZlXG4gKlxuICogQGhlbHBcbiAqIFJQRyBNYWtlciBNWiAtIENTVk5fYmF0dGxlQmdtLnRzICh0cmFuc3BpbGVkKVxuICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogKEMpMjAyMyBjdXJzZWRfc3RldmVuXG4gKiBUaGlzIHNvZnR3YXJlIGlzIHJlbGVhc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbiAqIGh0dHA6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9taXQtbGljZW5zZS5waHBcbiAqIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAqIFZlcnNpb25cbiAqIDEuMC4wICAyMDIzLzA3LzAyIFx1NTIxRFx1NzI0OFxuICogMS4xLjAgIDIwMjQvMDUvMDYgXHU1MTZDXHU5NThCXHU3NTI4XHUzMDZCXHU0RTAwXHU5MEU4XHU0RkVFXHU2QjYzXG4gKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gKiBbVHdpdHRlcl06IGh0dHBzOi8vdHdpdHRlci5jb20vY3Vyc2VkX3N0ZXZlblxuICpcbiAqIFx1NjIyNlx1OTVEOEJHTVx1MzA5Mlx1NjU3NVx1MzBCMFx1MzBFQlx1MzBGQ1x1MzBEN1x1MzA1NFx1MzA2OFx1MzA2Qlx1MzAwMVx1MzBEN1x1MzBFOVx1MzBCMFx1MzBBNFx1MzBGM1x1MzBEMVx1MzBFOVx1MzBFMVx1MzBGQ1x1MzBCRlx1MzA2N1x1NTAwQlx1NTIyNVx1MzA2Qlx1OEEyRFx1NUI5QVx1MzA2N1x1MzA0RFx1MzA3RVx1MzA1OVx1MzAwMlxuICpcbiAqIEBwYXJhbSBsaXN0XG4gKiBAdGV4dCBcdThBMkRcdTVCOUFcdTMwRUFcdTMwQjlcdTMwQzhcbiAqIEB0eXBlIHN0cnVjdDxCYXR0bGVCZ20+W11cbiAqL1xuXG4vKn5zdHJ1Y3R+QmF0dGxlQmdtOmphXG4gKlxuICogQHByZXNlcnZlXG4gKlxuICogQHBhcmFtIHRyb29wSWRcbiAqIEB0ZXh0IFx1NjU3NVx1MzBCMFx1MzBFQlx1MzBGQ1x1MzBEN1xuICogQHR5cGUgdHJvb3BcbiAqXG4gKiBAcGFyYW0gYmdtXG4gKiBAdGV4dCBCR01cbiAqIEB0eXBlIHN0cnVjdDxCZ21TZXR0aW5nPlxuICpcbiAqIEBwYXJhbSBiZ3NcbiAqIEB0ZXh0IEJHU1xuICogQHR5cGUgc3RydWN0PEJnc1NldHRpbmc+XG4gKi9cblxuLyp+c3RydWN0fkJnbVNldHRpbmc6amFcbiAqXG4gKiBAcHJlc2VydmVcbiAqXG4gKiBAcGFyYW0gbmFtZVxuICogQHRleHQgXHUzMEQ1XHUzMEExXHUzMEE0XHUzMEVCXHU1NDBEXG4gKiBAdHlwZSBmaWxlXG4gKiBAZGlyIGF1ZGlvL2JnbS9cbiAqXG4gKiBAcGFyYW0gdm9sdW1lXG4gKiBAdGV4dCBcdTk3RjNcdTkxQ0ZcbiAqIEB0eXBlIG51bWJlclxuICogQGRlZmF1bHQgOTBcbiAqXG4gKiBAcGFyYW0gcGl0Y2hcbiAqIEB0ZXh0IFx1MzBENFx1MzBDM1x1MzBDMVxuICogQHR5cGUgbnVtYmVyXG4gKiBAZGVmYXVsdCAxMDBcbiAqXG4gKiBAcGFyYW0gcGFuXG4gKiBAdGV4dCBcdTMwRDFcdTMwRjNcbiAqIEB0eXBlIG51bWJlclxuICogQGRlZmF1bHQgMFxuICovXG5cbi8qfnN0cnVjdH5CZ3NTZXR0aW5nOmphXG4gKlxuICogQHByZXNlcnZlXG4gKlxuICogQHBhcmFtIG5hbWVcbiAqIEB0ZXh0IFx1MzBENVx1MzBBMVx1MzBBNFx1MzBFQlx1NTQwRFxuICogQHR5cGUgZmlsZVxuICogQGRpciBhdWRpby9iZ3MvXG4gKlxuICogQHBhcmFtIHZvbHVtZVxuICogQHRleHQgXHU5N0YzXHU5MUNGXG4gKiBAdHlwZSBudW1iZXJcbiAqIEBkZWZhdWx0IDkwXG4gKlxuICogQHBhcmFtIHBpdGNoXG4gKiBAdGV4dCBcdTMwRDRcdTMwQzNcdTMwQzFcbiAqIEB0eXBlIG51bWJlclxuICogQGRlZmF1bHQgMTAwXG4gKlxuICogQHBhcmFtIHBhblxuICogQHRleHQgXHUzMEQxXHUzMEYzXG4gKiBAdHlwZSBudW1iZXJcbiAqIEBkZWZhdWx0IDBcbiAqL1xuXG5pbXBvcnQgeyBCYXR0bGVCZ20gfSBmcm9tIFwiIy9AdHlwZXMvcGx1Z2lucy9DU1ZOX2JhdHRsZUJnbVwiO1xuXG5jb25zdCBDU1ZOX2JhdHRsZUJnbTogUGx1Z2luQ29uc3RzID0ge1xuICAgIHBhcmFtczogUGx1Z2luTWFuYWdlckV4LmNyZWF0ZVBhcmFtZXRlcihkb2N1bWVudC5jdXJyZW50U2NyaXB0KSxcbiAgICBpcGNSZW5kZXJlcjogbnVsbCxcbn07XG5cbi8vIGNvbnNvbGUubG9nKFwiPj4+Pj4+Pj4gSGVsbG8gZnJvbSBDU1ZOX2JhdHRsZUJnbS5cIiwgQ1NWTl9iYXR0bGVCZ20ucGFyYW1zKTtcblxuY29uc3QgYmF0dGxlQmdtTGlzdDogQmF0dGxlQmdtW10gPSBDU1ZOX2JhdHRsZUJnbS5wYXJhbXMubGlzdDtcblxuLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gQmF0dGxlTWFuYWdlclxuXG5jb25zdCBfQmF0dGxlTWFuYWdlcl9wbGF5QmF0dGxlQmdtX2JiZyA9IEJhdHRsZU1hbmFnZXIucGxheUJhdHRsZUJnbTtcbkJhdHRsZU1hbmFnZXIucGxheUJhdHRsZUJnbSA9IGZ1bmN0aW9uICh0aGlzOiBCYXR0bGVNYW5hZ2VyKSB7XG4gICAgY29uc3QgdHJvb3BJZCA9ICRnYW1lVHJvb3AuX3Ryb29wSWQ7XG4gICAgY29uc3QgYmF0dGxlQmdtOiBCYXR0bGVCZ20gPSBiYXR0bGVCZ21MaXN0LmZpbmQoXG4gICAgICAgIChiKSA9PiBiLnRyb29wSWQgPT09IHRyb29wSWRcbiAgICApO1xuICAgIGlmIChiYXR0bGVCZ20pIHtcbiAgICAgICAgaWYgKGJhdHRsZUJnbS5iZ20pIHtcbiAgICAgICAgICAgIEF1ZGlvTWFuYWdlci5wbGF5QmdtKGJhdHRsZUJnbS5iZ20sIDApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgQXVkaW9NYW5hZ2VyLnJlcGxheUJnbShCYXR0bGVNYW5hZ2VyLl9tYXBCZ20pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChiYXR0bGVCZ20uYmdzKSB7XG4gICAgICAgICAgICBBdWRpb01hbmFnZXIucGxheUJncyhiYXR0bGVCZ20uYmdzLCAwKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIEF1ZGlvTWFuYWdlci5yZXBsYXlCZ3MoQmF0dGxlTWFuYWdlci5fbWFwQmdzKTtcbiAgICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAgIF9CYXR0bGVNYW5hZ2VyX3BsYXlCYXR0bGVCZ21fYmJnLmNhbGwodGhpcyk7XG4gICAgfVxufTtcbiJdLAogICJtYXBwaW5ncyI6ICI7O0FBaUdBLE1BQU0saUJBQStCO0FBQUEsSUFDakMsUUFBUSxnQkFBZ0IsZ0JBQWdCLFNBQVMsYUFBYTtBQUFBLElBQzlELGFBQWE7QUFBQSxFQUNqQjtBQUlBLE1BQU0sZ0JBQTZCLGVBQWUsT0FBTztBQUt6RCxNQUFNLG1DQUFtQyxjQUFjO0FBQ3ZELGdCQUFjLGdCQUFnQixXQUErQjtBQUN6RCxVQUFNLFVBQVUsV0FBVztBQUMzQixVQUFNLFlBQXVCLGNBQWM7QUFBQSxNQUN2QyxDQUFDLE1BQU0sRUFBRSxZQUFZO0FBQUEsSUFDekI7QUFDQSxRQUFJLFdBQVc7QUFDWCxVQUFJLFVBQVUsS0FBSztBQUNmLHFCQUFhLFFBQVEsVUFBVSxLQUFLLENBQUM7QUFBQSxNQUN6QyxPQUFPO0FBQ0gscUJBQWEsVUFBVSxjQUFjLE9BQU87QUFBQSxNQUNoRDtBQUNBLFVBQUksVUFBVSxLQUFLO0FBQ2YscUJBQWEsUUFBUSxVQUFVLEtBQUssQ0FBQztBQUFBLE1BQ3pDLE9BQU87QUFDSCxxQkFBYSxVQUFVLGNBQWMsT0FBTztBQUFBLE1BQ2hEO0FBQUEsSUFDSixPQUFPO0FBQ0gsdUNBQWlDLEtBQUssSUFBSTtBQUFBLElBQzlDO0FBQUEsRUFDSjsiLAogICJuYW1lcyI6IFtdCn0K
