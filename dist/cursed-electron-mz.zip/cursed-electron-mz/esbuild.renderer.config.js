import glob from "glob";

/** @var {Partial<import('esbuild').BuildOptions>} */
export const platform = "browser";
export const entryPoints = glob.sync("src/plugins/*.ts");
export const bundle = true;
export const target = "chrome89";
export const loader = {
    ".ts": "ts",
};
